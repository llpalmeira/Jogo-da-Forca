/**
 * Jogo da Forca (Hangman)
 * @author Leandro Palmeira
 * @link https://github.com/llpalmeira/Jogo-da-Forca
 * Criado em 2020/06/24
 */
package llpalmeira.interfaces;

public interface Jogo {
	
	void jogar();
	void inserirPalavras();
	void inserirJogadores();
	void escolheCategoria();
	void imprimeDados();
	void desenha();
	

}
