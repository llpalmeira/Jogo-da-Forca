/**
 * Jogo da Forca (Hangman)
 * @author Leandro Palmeira
 * @link https://github.com/llpalmeira/Jogo-da-Forca
 * Criado em 2020/06/24
 */
package llpalmeira.execucao;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Scanner;

import llpalmeira.interfaces.Jogo;
import llpalmeira.objetos.Categoria;
import llpalmeira.objetos.Jogador;

public class Inicio implements Jogo {
	private String palavrasorteada;
	private String contaletras="";
	private String categoriasorteada;
	private Scanner ler;

	// Construtor
	public Inicio() {
	}

	private ArrayList <Jogador> jogadores = new ArrayList<>();
	private ArrayList <Categoria> categorias = new ArrayList<>();
	private String palavraoculta;
	private int erros;
	private int totaljogadores=0;
	private int jogadoratual=0;
	private boolean acertou = false;

	public static void main(String[] args) {

		Inicio forca = new Inicio();

		forca.iniciar();


		System.out.println("\nFinalizando . . .");
		System.exit(0);



	}//------------------------------- IN�CIO DOS M�TODOS  -----------------------------------

	//
	public void  iniciar() {
		ler = new Scanner(System.in);


		titulo();
		carregaCategorias();
		opcoes1();


		ler.close();
	}


	// Insere o t�tulo do jogo
	public void  titulo() {
		System.out.println();
		System.out.println("\t|||||||||||||||||||||||");
		//		System.out.println("\t||                   ||");
		System.out.println("\t|||  JOGO DA FORCA  |||");
		//		System.out.println("\t||                   ||");
		System.out.println("\t|||||||||||||||||||||||");
		System.out.println();
	}


	public void  carregaCategorias() {
		System.out.println("\nCarregando categorias de palavras. . .\n");

		// Cria as categorias � partir de arquivos de texto
		Categoria cat0 = new Categoria();
		cat0.insereArquivo("Testes", "listasdepalavras/testes.txt");

		Categoria cat1 = new Categoria();
		cat1.insereArquivo("Arvores", "listasdepalavras/arvores.txt");

		Categoria cat2 = new Categoria();
		cat2.insereArquivo("Elementos Qu�micos", "listasdepalavras/elementosquimicos.txt");

		Categoria cat3 = new Categoria();
		cat3.insereArquivo("Frutas", "listasdepalavras/frutas.txt");

		Categoria cat4 = new Categoria();
		cat4.insereArquivo("Palavras Compostas", "listasdepalavras/palavrascompostas.txt");

		Categoria cat5 = new Categoria();
		cat5.insereArquivo("Palavras Gerais", "listasdepalavras/listageral.txt");

		// Insere as categoria na lista de categorias	
		categorias.add(cat0);	
		categorias.add(cat1);
		categorias.add(cat2);
		categorias.add(cat3);
		categorias.add(cat4);
		categorias.add(cat5);

		contaPalavras();
		ql(2);

	}

	public void  opcoes1() {
		System.out.println("\t             IN�CIO       \n");
		System.out.println("\t* * * * * * * * * * * * * *");
		System.out.println("\t*  1. Inserir jogadores   *");
		System.out.println("\t*  2. Jogar               *");
		System.out.println("\t*  3. Inserir palavras    *");
		System.out.println("\t*  4. Finalizar           *");
		System.out.println("\t* * * * * * * * * * * * * *");
		System.out.print("\nEscolha uma das op��es acima: ");
		escolheopcoes1();
	}

	public void  escolheopcoes1() {	
		int opc = 0;
		// Tratamento da exce��o
		try {			
			opc = Integer.parseInt(ler.nextLine());
		} catch (NumberFormatException e1) {
			System.out.println("\n\nEntrada inv�lida . . .\n\n\n");
			opcoes1();
			e1.printStackTrace();
		}

		switch(opc) {
		case 1:
			inserirJogadores();
			opcoes1();
			break;
		case 2:
			jogar();
			break;
		case 3:
			inserirPalavras();
			break;
		case 4:
			// Finaliza o programa
			try {
				finalize();
			} catch (Throwable e) {
				e.printStackTrace();
			}
			break;
		default:
			System.out.println("\nEntrada inv�lida . . .\n");
			opcoes1();
		}
		return;	
	}


	public void  inserirJogadores() {
		System.out.println("\nInserindo jogadores . . . \n");
		char resp = 's';

		do {
			System.out.print("Digite o nome do "+ (jogadores.size()+1) +String.format("%c", 176)+" jogador: ");
			Jogador novojogador = new Jogador();
			String nome = ler.nextLine();
			novojogador.insereJogador(nome);	
			jogadores.add(novojogador);
			
			System.out.print("\nDeseja inserir outro jogador?   (S/N): ");
			resp = ler.nextLine().charAt(0);
			if((resp=='n'||resp=='N')) {
				return;
			}
			
			ql();		
		}while ((resp=='s'|| resp=='S'));
		
		ql(2);
		return;
	}





	public void jogar() {
		if (!jogadores.isEmpty()) {
			jogadoratual = 0;
			totaljogadores = jogadores.size();				
			ql(2);
			mostraCategorias();
		}else {
			System.out.println("\nN�o foram inseridos os jogadores!\n");
			System.out.println("Insira pelo menos 1 jogador na lista\n\n");
			opcoes1();
		}
	}

	public void  mostraCategorias() {		
		ln();
		listaCategorias();
		System.out.print(" "+jogadores.get(jogadoratual).getNome());
		System.out.println(", escolha a categoria desejada:");
		ln();	
		escolheCategoria();	
			
	}

	public void  listaCategorias() {
		System.out.println("\t          CATEGORIAS       \n");
		System.out.println("1. Testes");
		System.out.println("2. Arvores");
		System.out.println("3. Elementos Qu�micos");
		System.out.println("4. Frutas");
		System.out.println("5. Palavras Compostas");
		System.out.println("6. Palavras Gerais");
		System.out.println("7. VOLTAR");
		ln();

	}

	public void  escolheCategoria() {
		int opc=0;


		try {			
			opc = Integer.parseInt(ler.nextLine());
		} catch (NumberFormatException e2) {
			System.out.println("\n\nEntrada inv�lida . . .\n\n\n");
			mostraCategorias();
			e2.printStackTrace();
		}

		switch(opc) {
		case 1:
			jogar(opc);
			break;
		case 2 :
			jogar(opc);

			break;
		case 3:
			jogar(opc);
			break;
		case 4:
			jogar(opc);
			break;
		case 5 :
			jogar(opc);

			break;
		case 6:
			jogar(opc);
			break;
		case 7:
			ql(2);
			opcoes1();
			break;	
		default:			
			System.out.println("\n\nEntrada inv�lida . . .\n\n\n");
			mostraCategorias();
		}		
		return;	
	}

	public void  jogar(int opc) {
		palavrasorteada = categorias.get((opc-1)).sorteiaPalavra().toUpperCase();
		categoriasorteada = categorias.get((opc-1)).getNomedacategoria();
		palavraoculta = palavrasorteada.replaceAll("[^ ^-]", "_");

		iniciaJogo();	
		mostraCategorias();
	}


	// Substitui as letras por underlines (exceto os hifens e espa�os)
	public String ocultaPalavra(String palavra) {	
		palavra = palavra.replaceAll("[^ ^-]", "_");		
		return palavra;
	}



	public void  iniciaJogo() {	
		char resp='s';

		// DESENHO INICIAL
		desenha();
		//desenhoInicial();

		if (acertou==false) {
			while ((erros < 6 && palavraoculta.contains("_"))) {	
				ql(1);

				// DESENHA ERROS E/OU ACERTOS
				//desenha();

				imprimeCaracteres(palavraoculta);
				ql(2);
				
				
				String palavradigitada=null;			
				do {
					System.out.print("Digite uma letra ou palavra: ");
					palavradigitada = ler.nextLine();
				}while(palavradigitada.length()==0);
		
				palavradigitada = palavradigitada.toUpperCase();
				
		
				comparaString(palavradigitada);
			}				
		}
		// Computa a pontua��o feita atrav�s das letras que ficaram escondidas
		int pparciais = jogadores.get(jogadoratual).getLetrasrestantes()*15;
		jogadores.get(jogadoratual).inserePontuacao(pparciais);

		zeraVariaveis();

		if (jogadoratual<totaljogadores) {
			jogadoratual++;
		}
		if(jogadoratual>=totaljogadores) {
			//	jogadoratual=0;

		}	
		

		System.out.print("\nDeseja continuar (S/N): ");
		resp=ler.nextLine().charAt(0);	

		if(resp=='s'||resp=='S') {
			ql(2);	
			mostraCategorias();
		}else {
			mostrarPontuacao();
			ql(2);
			System.out.println("\nFinalizando . . .");
			System.exit(0);
		}		
	}



	public void  imprimeCaracteres(String palavra) {
		imprimeDados();
		imprimePalavra(palavra);
		return;
	}

	public void  imprimeDados(){
		System.out.println();
		System.out.println("Chances           : " +(6-erros));
		System.out.println("Erros             : " +erros);
		System.out.println("Categoria         : "+ categoriasorteada);
		System.out.print("Letras utilizadas : ");
		imprimePalavra(contaletras);
		System.out.print("\n\nPalavra oculta  :\t  ");	
	}	


	public void  imprimePalavra(String palavra) {
		int x=0;
		while(x<palavra.length()) {
			System.out.print(palavra.charAt(x)+" ");
			x++;
		}
		return;
	}

	//Compara as letras (ou palavra)
	public void  comparaString(String stringdigitada)  {

		// Se o jogador digitou a palavra inteira ele finaliza
		if(stringdigitada.contentEquals(palavrasorteada)) {
			acertou = true;
			System.out.println("Voc� acertou a palavra\n");

			int cont=0;
			for(int i=0; i<palavraoculta.length();i++) {
				if(palavraoculta.charAt(i)=='_') {
					cont++;
				}			
			}

			jogadores.get(jogadoratual).setLetrasrestantes(cont);
			palavraoculta = palavrasorteada;

		}else if(stringdigitada.length()>1) {
			stringdigitada="*";
		}

		char letradigitada = stringdigitada.charAt(0);
		String concatenando = "";

		// ComparaLetra(letradigitada);
		for (int i = 0; i < palavrasorteada.length(); i++) {

			// Percorre a palavra comparando a letra
			if (palavrasorteada.charAt(i) == letradigitada) { 
				
				concatenando +=letradigitada;
				
				// SE A PALAVRA OCULTA N�O FOR _ NA POSI��O i
			} else if (palavraoculta.charAt(i) != '_') { 

				concatenando += palavrasorteada.charAt(i);	

			} else {			
				// Preenche com _ onde n�o s�o iguais as letras
				concatenando += "_";
			}

		}

		// AP�S COMPARAR A LETRA . . . 

		if (palavraoculta.equals(concatenando)) { 
			
			if(acertou==false) {
				erros++;
			}

			// DESENHA ERROS
			guardaLetras(letradigitada);
			desenha();
		} else { 
			palavraoculta = concatenando;
			// DESENHA ACERTOS
			guardaLetras(letradigitada);
			desenha();
		}

		// Verifica se as palavras j� s�o iguais
		comparaPalavras();
	}

	// Compara palavras
	public void  comparaPalavras() {
		if (palavraoculta.equals(palavrasorteada)) {
			imprimeCaracteres(palavraoculta);
			ql(2);
			this.jogadores.get(jogadoratual).inserePontuacao(100);
			System.out.println("Parab�ns, voc� acertou!");
			System.out.println("A palavra era " + "'" + palavrasorteada + "'");
			System.out.println("Ficaram "+jogadores.get(jogadoratual).getLetrasrestantes()+" letras ocultas");
		}

	}



	public void  guardaLetras(char ch) {
		int cont=0;
		if (contaletras.length()==0) {
			contaletras +=ch;

		}else {
			for(int j=0;j<contaletras.length();j++) {
				if ( (contaletras.charAt(j)) == ch) {
					cont++;
				}
			}
			if(cont==0) {
				contaletras +=ch;
			}
		}

	}


	public void  zeraVariaveis() {
		erros = 0;
		palavraoculta = null;
		palavrasorteada = null;
		categoriasorteada = null;
		contaletras = "";
		acertou = false;
	}


	//------------ Desenhos -----------------------------

	public void  desenha() {
		ql(5);
		System.out.println("Jogador:" + jogadores.get(jogadoratual).getNome());
		if (erros == 0) {
			System.out.println("   ____________");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("___|___");
		}

		if (erros == 1) {
			System.out.println("   ____________");
			System.out.println("   |          _|_");
			System.out.println("   |         ////\\");
			System.out.println("   |        | *.* |");
			System.out.println("   |         \\_=_/");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("___|___");
		}
		if (erros == 2) {
			System.out.println("   ____________");
			System.out.println("   |          _|_");
			System.out.println("   |         ////\\");
			System.out.println("   |        | *.* |");
			System.out.println("   |         \\_=_/");
			System.out.println("   |           |");
			System.out.println("   |           |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |   ");	System.out.println("   |");
			System.out.println("___|___");
		}
		if (erros == 3) {
			System.out.println("   ____________");
			System.out.println("   |          _|_");
			System.out.println("   |         ////\\");
			System.out.println("   |        | *.* |");
			System.out.println("   |         \\_=_/");
			System.out.println("   |          _|");
			System.out.println("   |         / | ");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("___|___");
		}
		if (erros == 4) {
			System.out.println("   ____________");
			System.out.println("   |          _|_");
			System.out.println("   |         ////\\");
			System.out.println("   |        | *.* |");
			System.out.println("   |         \\_=_/");
			System.out.println("   |          _|_");
			System.out.println("   |         / | \\");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("___|___");
		}
		if (erros == 5) {
			System.out.println("   ____________");
			System.out.println("   |          _|_");
			System.out.println("   |         ////\\");
			System.out.println("   |        | *.* |");
			System.out.println("   |         \\_=_/");
			System.out.println("   |          _|_");
			System.out.println("   |         / | \\");
			System.out.println("   |          / ");
			System.out.println("   |         /   ");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("___|___");
		}
		if (erros == 6) {
			System.out.println("\n\n");
			System.out.println("FIM DO JOGO!");
			System.out.println("VOC� N�O ACERTOU!");
			System.out.println("   ____________");
			System.out.println("   |          _|_");
			System.out.println("   |         ////\\");
			System.out.println("   |        | *.* |");
			System.out.println("   |         \\_=_/");
			System.out.println("   |          _|_");
			System.out.println("   |         / | \\");
			System.out.println("   |          / \\ ");
			System.out.println("   |         /   \\");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("   |");
			System.out.println("___|___");

			System.out.println("A palavra era " + palavrasorteada);

		}

	}




	//------------ Inserir Palavras nas Listas---------------


	public void  inserirPalavras() {
		ql(10);
		
		System.out.println("\nEscolha a categoria que deseja inserir palavras");
		ln();
		ql(2);
		listaCategorias();

		escolheInsercao();

	}
	
	
	public void  escolheInsercao() {
			int opc=0;
			System.out.print("Digite a op��o desejada: ");
			try {			
				opc = Integer.parseInt(ler.nextLine());
			} catch (NumberFormatException e2) {
				System.out.println("\n\nEntrada inv�lida . . .\n\n\n");
				inserirPalavras();
				e2.printStackTrace();
			}

			switch(opc) {
			case 1:
				inserirPalavra(opc);
				break;
			case 2 :
				inserirPalavra(opc);

				break;
			case 3:
				inserirPalavra(opc);
				break;
			case 4:
				inserirPalavra(opc);
				break;
			case 5 :
				inserirPalavra(opc);

				break;
			case 6:
				inserirPalavra(opc);
				break;
			case 7:
				ql(2);
				opcoes1();
				break;	
			default:			
				System.out.println("\n\nEntrada inv�lida . . .\n\n\n");
				inserirPalavras();
			}		
			return;	
		
	}
	
	
	
	
	// Insere palavras em uma categoria
	
	public void  inserirPalavra(int opc) {
		System.out.print("\nInserindo na categoria \""+ categorias.get(opc-1).getNomedacategoria()+"\"\n\n");
		char resp = 's';
		

		do {
			
			String novapalavra=null;			
			do {
				System.out.print("Digite uma letra ou palavra: ");
				novapalavra = ler.nextLine();
			}while(novapalavra.length()==0);
	
			novapalavra = novapalavra.toUpperCase();
			
			categorias.get(opc-1).inserePalavra(novapalavra);
			
			System.out.println("Palavra inserida com sucesso!");
			System.out.println("Total: " + categorias.get(opc-1).quantPalavras()+" palavras");
			
			
			String resposta=null;			
			do {
				System.out.print("\nDeseja inserir outra palavra nesta categoria?   (S/N): ");
				resposta = ler.nextLine();
			}while(resposta.length()==0);
			
			resp = resposta.charAt(0);
				

			
			if((resp=='n'||resp=='N')) {
				inserirPalavras();
			}
			
			ql();		
		}while ((resp=='s'|| resp=='S'));

		return;
	}



	public void  mostrarPontuacao() {
		ql(5);
		System.out.println("FIM DO JOGO!!!!!\n");
		ql(2);
		for (Jogador j: jogadores) {
			System.out.println("Jogador   :"+j.getNome());
			System.out.println("Pontua��o : "+j.getPontuacao());
			System.out.println();

		}

	}


	// Conta as palavras de todas as categorias
	public void  contaPalavras() {

		int quant=0;
		int totalpalavras=0;
		ln();
		for (int i =0; i<categorias.size();i++) {
			quant = this.categorias.get(i).quantPalavras();
			totalpalavras+= quant;
			System.out.println(this.categorias.get(i).getNomedacategoria() +": "+quant+" palavras");
			System.out.println("Subtotal: "+ totalpalavras);
			ql();
		}
		DecimalFormat df = new DecimalFormat();
		ln();
		System.out.println(" Total de palavras: "+df.format(totalpalavras));
		ln();

	}


	// Insere uma quebra de linha
	public void  ql() {
		System.out.println();
		return;
	}

	// Insere 'n' quebras de linha
	public void  ql(int n) {
		int ct=0;
		while (ct<n){
			System.out.println();
			ct++;
		}
		return;
	}

	public void  ln() {
		System.out.println("---------------------------------------");
	}


}
