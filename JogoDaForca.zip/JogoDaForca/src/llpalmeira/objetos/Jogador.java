/**
 * Jogo da Forca (Hangman)
 * @author Leandro Palmeira
 * @link https://github.com/llpalmeira/Jogo-da-Forca
 * Criado em 2020/06/24
 */
package llpalmeira.objetos;

public class Jogador extends Pessoa {

	private int pontuacao = 0;
	private int letrasrestantes = 0;

	// Construtores da SuperClasse

	public Jogador() {
		super();

	}	

	public Jogador(String nome) {
		super(nome);
		this.pontuacao = 0;
		this.letrasrestantes = 0;

	}

	public Jogador(String nome, int idade) {
		super(nome, idade);

	}

	// Getters e Setters


	public int getPontuacao() {
		return pontuacao;
	}

	public void setPontuacao(int pontuacao) {
		this.pontuacao = pontuacao;
	}

	public int getLetrasrestantes() {
		return letrasrestantes;
	}

	public void setLetrasrestantes(int letrasrestantes) {
		this.letrasrestantes = letrasrestantes;
	}

	// M�todos diversos


	public void insereJogador(String nome) {
		this.setNome(nome);
	}

	public void insereJogador(String nome, int idade) {
		this.setNome(nome);
		this.setIdade(idade);
	}

	public void inserePontuacao(int pontuacao) {
		this.setPontuacao( (this.getPontuacao()) + (pontuacao) );
	}

	public void insereLetrasRestantes(int letrasrestantes) {
		this.setLetrasrestantes(letrasrestantes);
	}

	public void resetPontuacaoTotal() {
		this.setPontuacao(0);
	}

	public void incrementaLetrasRestantes() {
		int letras = this.getLetrasrestantes();
		letras ++;
		this.setLetrasrestantes(letras);
	}

	public void decrementaLetrasRestantes() {
		int letras = this.getLetrasrestantes();
		letras -- ;
		this.setLetrasrestantes(letras);
	}


	public void mostraJogador() {
		//		System.out.println("Nome: "+ this.getNome());
		System.out.println(this.toString());
	}

	@Override
	public String toString(){

		return 
				"\nNome: " + this.getNome() +
				"\nIdade: " + this.getIdade() +
				"\nPontua��o Parcial: " + this.getPontuacao() +"\n";
	}




}
