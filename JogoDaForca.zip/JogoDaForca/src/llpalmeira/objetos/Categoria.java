/**
 * Jogo da Forca (Hangman)
 * @author Leandro Palmeira
 * @link https://github.com/llpalmeira/Jogo-da-Forca
 * Criado em 2020/06/24
 */
package llpalmeira.objetos;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Categoria {
	
	private String nomedacategoria;
	private ArrayList <String> palavras;
	
	
	// M�todos construtores
	
	
	public Categoria() {

	}
	
	public Categoria(String nomedacategoria) {
		this.nomedacategoria = nomedacategoria;
	}
	
	public Categoria(ArrayList<String> palavras) {
		this.palavras = palavras;
	}
	
	public Categoria(String nomedacategoria, ArrayList<String> palavras) {
		super();
		this.nomedacategoria = nomedacategoria;
		this.palavras = palavras;
	}
	

	// Getters e Setters
	
	
	public String getNomedacategoria() {
		return nomedacategoria;
	}

	public void setNomedacategoria(String nomedacategoria) {
		this.nomedacategoria = nomedacategoria;
	}

	public ArrayList<String> getPalavras() {
		return palavras;
	}

	public void setPalavras(ArrayList<String> palavras) {
		this.palavras = palavras;
	}
	
	
	
	// M�todos Diversos
	
	
	// Insere uma categoria, vazia (apenas nome da categoria, com a lista de palavras vazia) 
	public void insereCategoria(String nomedacategoria) {		
		this.setNomedacategoria(nomedacategoria);
		this.setPalavras(null);		
	}
	
	
	// Insere uma categoria � partir de um ArrayList
	public void insereCategoria(String nomedacategoria, ArrayList<String> palavras) {		
		this.setNomedacategoria(nomedacategoria);
		this.setPalavras(palavras);		
	}
	
	// Insere uma categoria � partir de um arquivo
	public void insereArquivo( String nomedacategoria, String caminho) {
	/* 	Chama o metodo para inserir uma categoria, passando como segundo par�metro
 		o retorno do  m�todo leArquivo(), que � um ArrayList de palavras.*/
		insereCategoria(nomedacategoria, leArquivo(caminho));
	}
	
	
	// L� um arquivo de texto e retorna um ArrayList
	public ArrayList<String> leArquivo(String caminho){
		// caminho = "listas/frutas.txt"
		
		// Cria o ArrayList que receber� as palavras(linhas) lidas do arquivo de texto
			ArrayList<String> listagerada = new ArrayList<String>(); 
		
		try {
			
			FileReader arquivo = new FileReader(caminho);
			BufferedReader lerarquivo = new BufferedReader(arquivo);
			// Copiando as linhas do arquivo para a lista
			String linhalida;	
			while((linhalida = lerarquivo.readLine())!= null) {    	
			    listagerada.add(linhalida);
			}		
			lerarquivo.close();
		}catch(FileNotFoundException ffe) {
			System.out.println("\n < < < Problemas ao ler o arquivo > > >\n");
			} catch (IOException e) {
				System.out.println("\n Erro\n");
			e.printStackTrace();
		}	
		return listagerada;		
	}

	
	// Altera o nome de uma categoria existente
	
	public void alteraNomeDaCategoria(String nome) {
		this.setNomedacategoria(nome);	
	}
	
	// Insere uma nova palavra em uma categoria j� existente
	public void inserePalavra(String palavra) {
		this.palavras.add(palavra);
	
	}
	
	// Mostra a categoria e sua lista de palavras
	public void mostraCategoria(){
		  System.out.println( "\nCategoria: " + this.getNomedacategoria());
		  this.imprimeFor();
		  }
	
	// Imprime o nome da categoria
	public void mostraNome(){
		  System.out.println( this.getNomedacategoria());
		  }
	
	
	
	// Imprime na tela a categoria, atrav�s do m�todo for simples
	public void imprimeFor() {
		System.out.println(this.toString());
//		System.out.println("\nImprime for: \n");
			for (int i = 0; i < this.palavras.size(); i++) {
				
				System.out.print("\t");
				System.out.println(palavras.get(i).toString());
				}
			}
	
	public void imprimeForEach() {
		//		System.out.println("\nImprime for Each: \n");
		System.out.println(this.toString());
		for (String palavra: this.palavras) {
			System.out.print("\t");
			System.out.println(palavra);
		}

	}	
	
	@Override
	public String toString() {
		return "\t " +this.palavras.size() + " palavras\n\n";
		
	}
	
	
	public String sorteiaPalavra() {
		String palavrasorteada;
		int index =  (int) (Math.random() * (this.getPalavras().size()));
		palavrasorteada = this.getPalavras().get(index);				
		return palavrasorteada;
	}
	
	public int quantPalavras() {
		
		return this.palavras.size();
	}
	
/*	
	public void imprimeEspacos(String palavra) {

		int index = 0;
		while (index<palavra.length()) {
		
			if(palavra.charAt(index)==32) {
				System.out.printf("%c ",32);
			}if(palavra.charAt(index)==45) {
				System.out.print(" -");
			}else {
				System.out.print(" _");
			}			
			index++;
		}
		
		System.out.println("\n\n");	
	}
*/
}
