/**
 * Jogo da Forca (Hangman)
 * @author Leandro Palmeira
 * @link https://github.com/llpalmeira/Jogo-da-Forca
 * Criado em 2020/06/24
 */
package llpalmeira.objetos;

public abstract class Pessoa {
	
	private String nome;
	private int idade;
	
	
	// M�todos construtores
	public Pessoa() {

	}
	
	public Pessoa(String nome) {

		this.nome = nome;
	}
	
	public Pessoa(String nome, int idade) {
		super();
		this.nome = nome;
		this.idade = idade;
	}
	
	// Getters e Setters

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}
	

}
